
This was the version of python used, as well as the python extension in vscode
https://www.python.org/downloads/release/python-3130/
Python 3.13.0

To Execute (replace input.txt with whatever the text document used for input):
python3 osproj5.py < input.txt 



Example Input:
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
3
FIFO
LRU


Example Output:
Page Reference String:
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
Number of Frames: 3
FIFO: 15
LRU: 12